[openai_usage_logs://<name>]
account = Select the OpenAI account to use.
index = Splunk index to store events. (Default: default)
interval = Polling interval in seconds. Usage API data has ~1-day lag; 3600 (1 hour) is recommended. (Default: 3600)
start_date = Earliest date to collect usage data (YYYY-MM-DD). Defaults to 30 days ago if not set.

[openai_audit_logs://<name>]
account = Select the OpenAI account to use.
effective_at_gte = Only return audit logs on or after this Unix timestamp. Leave blank to use checkpoint-based continuation.
index = Splunk index to store events. (Default: default)
interval = Polling interval in seconds. 300 (5 minutes) is recommended. (Default: 300)
